import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;

public class framework9 extends JFrame {

	private JPanel contentPane;
	private JTextField txtNameVicentiusTheron;
	private JTextField txtLrn;
	private JTextField txtDateOfBirth;
	private JTextField txtParentguardianMrAnd;
	private JTextField textField_4;
	private JTextField txtElementaryCebuBradford;
	private JTextField textField_6;
	private JTextField txtSexMale;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework9 frame = new framework9();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework9() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1081, 821);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBounds(10, 11, 1077, 790);
		contentPane.add(contentPane_1);
		
		txtNameVicentiusTheron = new JTextField();
		txtNameVicentiusTheron.setToolTipText("Name: Liliene Ylena Altamirano");
		txtNameVicentiusTheron.setText("Name: Vicentius Theron Hidalgo\r\n");
		txtNameVicentiusTheron.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtNameVicentiusTheron.setColumns(10);
		txtNameVicentiusTheron.setBounds(34, 61, 352, 31);
		contentPane_1.add(txtNameVicentiusTheron);
		
		txtLrn = new JTextField();
		txtLrn.setText("LRN:764341084627\r\n");
		txtLrn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtLrn.setColumns(10);
		txtLrn.setBounds(34, 103, 352, 31);
		contentPane_1.add(txtLrn);
		
		txtDateOfBirth = new JTextField();
		txtDateOfBirth.setText("Date of Birth: 1/15/04\r\n");
		txtDateOfBirth.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtDateOfBirth.setColumns(10);
		txtDateOfBirth.setBounds(34, 145, 352, 31);
		contentPane_1.add(txtDateOfBirth);
		
		txtParentguardianMrAnd = new JTextField();
		txtParentguardianMrAnd.setText("Parent/Guardian: Mr. and Mrs. Hidalgo\r\n");
		txtParentguardianMrAnd.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtParentguardianMrAnd.setColumns(10);
		txtParentguardianMrAnd.setBounds(34, 187, 352, 31);
		contentPane_1.add(txtParentguardianMrAnd);
		
		textField_4 = new JTextField();
		textField_4.setText("School Attended:");
		textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_4.setColumns(10);
		textField_4.setBounds(34, 236, 352, 31);
		contentPane_1.add(textField_4);
		
		txtElementaryCebuBradford = new JTextField();
		txtElementaryCebuBradford.setText("Elementary: Cebu Bradford School\r\n");
		txtElementaryCebuBradford.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtElementaryCebuBradford.setColumns(10);
		txtElementaryCebuBradford.setBounds(34, 278, 352, 31);
		contentPane_1.add(txtElementaryCebuBradford);
		
		textField_6 = new JTextField();
		textField_6.setText("Junior highschool: Southwestern University\r\n");
		textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_6.setColumns(10);
		textField_6.setBounds(33, 320, 352, 30);
		contentPane_1.add(textField_6);
		
		txtSexMale = new JTextField();
		txtSexMale.setText("Sex: Male");
		txtSexMale.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtSexMale.setColumns(10);
		txtSexMale.setBounds(448, 66, 242, 24);
		contentPane_1.add(txtSexMale);
		
		textField_8 = new JTextField();
		textField_8.setText("Year Graduated: 2021");
		textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_8.setColumns(10);
		textField_8.setBounds(448, 325, 242, 20);
		contentPane_1.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setText("Year Graduated:: 2017");
		textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_9.setColumns(10);
		textField_9.setBounds(448, 283, 242, 20);
		contentPane_1.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setText("TRACK:                         ACADEMIC");
		textField_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_10.setColumns(10);
		textField_10.setBounds(34, 484, 352, 31);
		contentPane_1.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setText("STRAND:                               TVL");
		textField_11.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_11.setColumns(10);
		textField_11.setBounds(34, 548, 352, 31);
		contentPane_1.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setText("BATCH: 2021-2022");
		textField_12.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_12.setColumns(10);
		textField_12.setBounds(448, 486, 333, 26);
		contentPane_1.add(textField_12);
	}

}
