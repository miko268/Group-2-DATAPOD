import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class framework15 extends JFrame {

	private JPanel contentPane;
	private JTextField txtDoYouWant;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework15 frame = new framework15();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework15() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1091, 809);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtDoYouWant = new JTextField();
		txtDoYouWant.setBackground(Color.WHITE);
		txtDoYouWant.setForeground(new Color(128, 0, 0));
		txtDoYouWant.setFont(new Font("Yu Gothic", Font.BOLD | Font.ITALIC, 20));
		txtDoYouWant.setHorizontalAlignment(SwingConstants.CENTER);
		txtDoYouWant.setText("DO YOU WANT TO LOG OUT ?");
		txtDoYouWant.setBounds(215, 252, 734, 64);
		contentPane.add(txtDoYouWant);
		txtDoYouWant.setColumns(10);
		
		JButton btnNewButton = new JButton("YES\r\n");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setBounds(519, 353, 102, 47);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("NO\r\n");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setBounds(519, 427, 102, 47);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\MIKO\\Downloads\\SAD.png"));
		lblNewLabel_1.setBounds(167, 103, 806, 109);
		contentPane.add(lblNewLabel_1);
	}

}
