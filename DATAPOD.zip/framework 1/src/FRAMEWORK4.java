import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class FRAMEWORK4 extends JFrame {

	private JPanel contentPane;
	private JTextField txtNameOfStudents;
	private JTextField txtallejereguelJameson;
	private JTextField txtAltamiranoLilieneYlena;
	private JTextField txtFortunadoThraia;
	private JTextField txtGalvezNieves;
	private JTextField txtHidalgoVicentius;
	private JTextField txtLevisteZariyah;
	private JTextField txtMercadejasAntonius;
	private JTextField txtRiegoRadleigh;
	private JTextField txtRiegoPercival;
	private JTextField txtSamuelEurydyce;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FRAMEWORK4 frame = new FRAMEWORK4();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FRAMEWORK4() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1093, 822);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNameOfStudents = new JTextField();
		txtNameOfStudents.setForeground(Color.PINK);
		txtNameOfStudents.setText("NAME OF TVL  STUDENTS\r\n");
		txtNameOfStudents.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		txtNameOfStudents.setHorizontalAlignment(SwingConstants.CENTER);
		txtNameOfStudents.setBounds(106, 184, 906, 64);
		contentPane.add(txtNameOfStudents);
		txtNameOfStudents.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\MIKO\\Downloads\\276986862_4772617479513843_9024251935593852877_n.jpg"));
		lblNewLabel.setBounds(255, 11, 554, 162);
		contentPane.add(lblNewLabel);
		
		txtallejereguelJameson = new JTextField();
		txtallejereguelJameson.setHorizontalAlignment(SwingConstants.LEFT);
		txtallejereguelJameson.setText("1.ALLEJE,REGUEL JAMESON\r\n");
		txtallejereguelJameson.setForeground(Color.BLACK);
		txtallejereguelJameson.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtallejereguelJameson.setBounds(99, 284, 506, 30);
		contentPane.add(txtallejereguelJameson);
		txtallejereguelJameson.setColumns(10);
		
		txtAltamiranoLilieneYlena = new JTextField();
		txtAltamiranoLilieneYlena.setText("2.Altamirano, Liliene Ylena");
		txtAltamiranoLilieneYlena.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtAltamiranoLilieneYlena.setBounds(99, 325, 506, 30);
		contentPane.add(txtAltamiranoLilieneYlena);
		txtAltamiranoLilieneYlena.setColumns(10);
		
		txtFortunadoThraia = new JTextField();
		txtFortunadoThraia.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtFortunadoThraia.setText("3. Fortunado, Thraia Gabriella ");
		txtFortunadoThraia.setBounds(99, 366, 506, 30);
		contentPane.add(txtFortunadoThraia);
		txtFortunadoThraia.setColumns(10);
		
		txtGalvezNieves = new JTextField();
		txtGalvezNieves.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtGalvezNieves.setText("4. Galvez, Nieves Solanna ");
		txtGalvezNieves.setBounds(99, 407, 506, 30);
		contentPane.add(txtGalvezNieves);
		txtGalvezNieves.setColumns(10);
		
		txtHidalgoVicentius = new JTextField();
		txtHidalgoVicentius.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtHidalgoVicentius.setText("5. Hidalgo, Vicentius Theron");
		txtHidalgoVicentius.setBounds(99, 448, 506, 30);
		contentPane.add(txtHidalgoVicentius);
		txtHidalgoVicentius.setColumns(10);
		
		txtLevisteZariyah = new JTextField();
		txtLevisteZariyah.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtLevisteZariyah.setText("6. Leviste, Zariyah Isla");
		txtLevisteZariyah.setBounds(99, 489, 506, 30);
		contentPane.add(txtLevisteZariyah);
		txtLevisteZariyah.setColumns(10);
		
		txtMercadejasAntonius = new JTextField();
		txtMercadejasAntonius.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtMercadejasAntonius.setText("7. Mercadejas, Antonius Lienzo");
		txtMercadejasAntonius.setBounds(99, 530, 506, 30);
		contentPane.add(txtMercadejasAntonius);
		txtMercadejasAntonius.setColumns(10);
		
		txtRiegoRadleigh = new JTextField();
		txtRiegoRadleigh.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtRiegoRadleigh.setText("8. Riego, Radleigh Vesarius\r\n");
		txtRiegoRadleigh.setBounds(99, 571, 507, 30);
		contentPane.add(txtRiegoRadleigh);
		txtRiegoRadleigh.setColumns(10);
		
		txtRiegoPercival = new JTextField();
		txtRiegoPercival.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtRiegoPercival.setText("9. Riego, Percival Archer");
		txtRiegoPercival.setBounds(99, 615, 506, 30);
		contentPane.add(txtRiegoPercival);
		txtRiegoPercival.setColumns(10);
		
		txtSamuelEurydyce = new JTextField();
		txtSamuelEurydyce.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtSamuelEurydyce.setText("10. Samuel, Eurydyce Amethyst");
		txtSamuelEurydyce.setBounds(99, 656, 506, 30);
		contentPane.add(txtSamuelEurydyce);
		txtSamuelEurydyce.setColumns(10);
		
		JButton btnNewButton = new JButton("Info & Grades");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.setBounds(644, 289, 259, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Info & Grades");
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_1.setBounds(644, 332, 259, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Info & Grades");
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_2.setBounds(644, 371, 259, 23);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Info & Grades");
		btnNewButton_3.setForeground(Color.RED);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_3.setBounds(644, 412, 259, 23);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Info & Grades");
		btnNewButton_4.setForeground(Color.RED);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_4.setBounds(644, 453, 259, 23);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Info & Grades");
		btnNewButton_5.setForeground(Color.RED);
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_5.setBounds(644, 494, 259, 23);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Info & Grades");
		btnNewButton_6.setForeground(Color.RED);
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_6.setBounds(644, 535, 259, 23);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Info & Grades");
		btnNewButton_7.setForeground(Color.RED);
		btnNewButton_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_7.setBounds(644, 576, 259, 23);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("Info & Grades");
		btnNewButton_8.setForeground(Color.RED);
		btnNewButton_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_8.setBounds(644, 620, 259, 23);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Info & Grades");
		btnNewButton_9.setForeground(Color.RED);
		btnNewButton_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_9.setBounds(644, 661, 259, 23);
		contentPane.add(btnNewButton_9);
	}

}
