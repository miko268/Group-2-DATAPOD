import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;

public class framework5 extends JFrame {

	private JPanel contentPane;
	private JTextField txtNameRiguelJameson;
	private JTextField txtLrn;
	private JTextField txtDateOfBirth;
	private JTextField txtParentguardianMrAnd;
	private JTextField txtSchoolAttended;
	private JTextField txtElementaryAlegriaElementary;
	private JTextField txtJuniorHighschoolsouthwesternUniverstiy;
	private JTextField txtSexMale;
	private JTextField txtYearGraduated_1;
	private JTextField txtYearGraduated;
	private JTextField txtTrackAcademic;
	private JTextField txtStrandTvl;
	private JTextField txtBatch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework5 frame = new framework5();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework5() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1093, 829);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNameRiguelJameson = new JTextField();
		txtNameRiguelJameson.setText("Name: Riguel Jameson Alleje");
		txtNameRiguelJameson.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtNameRiguelJameson.setBounds(34, 61, 352, 31);
		contentPane.add(txtNameRiguelJameson);
		txtNameRiguelJameson.setColumns(10);
		
		txtLrn = new JTextField();
		txtLrn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtLrn.setText("LRN: 182345690675");
		txtLrn.setBounds(34, 103, 352, 31);
		contentPane.add(txtLrn);
		txtLrn.setColumns(10);
		
		txtDateOfBirth = new JTextField();
		txtDateOfBirth.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtDateOfBirth.setText("Date of Birth: 5/21/04");
		txtDateOfBirth.setBounds(34, 145, 352, 31);
		contentPane.add(txtDateOfBirth);
		txtDateOfBirth.setColumns(10);
		
		txtParentguardianMrAnd = new JTextField();
		txtParentguardianMrAnd.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtParentguardianMrAnd.setText("Parent/Guardian: Mr. and Mrs. Alleje");
		txtParentguardianMrAnd.setBounds(34, 187, 352, 31);
		contentPane.add(txtParentguardianMrAnd);
		txtParentguardianMrAnd.setColumns(10);
		
		txtSchoolAttended = new JTextField();
		txtSchoolAttended.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtSchoolAttended.setText("School Attended:");
		txtSchoolAttended.setBounds(34, 236, 352, 31);
		contentPane.add(txtSchoolAttended);
		txtSchoolAttended.setColumns(10);
		
		txtElementaryAlegriaElementary = new JTextField();
		txtElementaryAlegriaElementary.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtElementaryAlegriaElementary.setText("Elementary: Alegria Elementary School");
		txtElementaryAlegriaElementary.setBounds(34, 278, 352, 31);
		contentPane.add(txtElementaryAlegriaElementary);
		txtElementaryAlegriaElementary.setColumns(10);
		
		txtJuniorHighschoolsouthwesternUniverstiy = new JTextField();
		txtJuniorHighschoolsouthwesternUniverstiy.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtJuniorHighschoolsouthwesternUniverstiy.setText("Junior highschool: Southwestern University\r\n");
		txtJuniorHighschoolsouthwesternUniverstiy.setBounds(33, 320, 352, 30);
		contentPane.add(txtJuniorHighschoolsouthwesternUniverstiy);
		txtJuniorHighschoolsouthwesternUniverstiy.setColumns(10);
		
		txtSexMale = new JTextField();
		txtSexMale.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtSexMale.setText("Sex: Male");
		txtSexMale.setBounds(448, 66, 242, 24);
		contentPane.add(txtSexMale);
		txtSexMale.setColumns(10);
		
		txtYearGraduated_1 = new JTextField();
		txtYearGraduated_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtYearGraduated_1.setText("Year Graduated: 2021");
		txtYearGraduated_1.setBounds(448, 325, 242, 20);
		contentPane.add(txtYearGraduated_1);
		txtYearGraduated_1.setColumns(10);
		
		txtYearGraduated = new JTextField();
		txtYearGraduated.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtYearGraduated.setText("Year Graduated:: 2017");
		txtYearGraduated.setBounds(448, 283, 242, 20);
		contentPane.add(txtYearGraduated);
		txtYearGraduated.setColumns(10);
		
		txtTrackAcademic = new JTextField();
		txtTrackAcademic.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtTrackAcademic.setText("TRACK:                         ACADEMIC");
		txtTrackAcademic.setBounds(34, 484, 352, 31);
		contentPane.add(txtTrackAcademic);
		txtTrackAcademic.setColumns(10);
		
		txtStrandTvl = new JTextField();
		txtStrandTvl.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtStrandTvl.setText("STRAND:                               TVL");
		txtStrandTvl.setBounds(34, 548, 352, 31);
		contentPane.add(txtStrandTvl);
		txtStrandTvl.setColumns(10);
		
		txtBatch = new JTextField();
		txtBatch.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtBatch.setText("BATCH: 2021-2022");
		txtBatch.setBounds(448, 486, 333, 26);
		contentPane.add(txtBatch);
		txtBatch.setColumns(10);
	}

}
