import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.Font;

public class framework5grade extends JFrame {

	private JPanel contentPane;
	private JTextField txtCodeNo;
	private JTextField txtGrade;
	private JTextField txtstGrading;
	private JTextField txtndGrading;
	private JTextField txtAverage;
	private JTextField txtRemarks;
	private JTextField txtUnitsEarned;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField txtPassed;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField txtPassed_1;
	private JTextField textField_40;
	private JTextField textField_41;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JTextField textField_45;
	private JTextField textField_46;
	private JTextField txtCorOral;
	private JTextField txtCorkomunikasyon;
	private JTextField txtCor;
	private JTextField txtCor_1;
	private JTextField txtCorst;
	private JTextField txtCorIntroduction;
	private JTextField txtCorphysical;
	private JTextField txtAap;
	private JTextField txtSubjectDesciption;
	private JTextField txtOutlineOfSenior;
	private JTextField txtSsp;
	private JTextField txtCompleted;
	private JTextField textField_2;
	private JTextField txtTotalUnitsEarned;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework5grade frame = new framework5grade();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework5grade() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1092, 835);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtCodeNo = new JTextField();
		txtCodeNo.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtCodeNo.setHorizontalAlignment(SwingConstants.CENTER);
		txtCodeNo.setText("Code no. ");
		txtCodeNo.setBackground(new Color(139, 0, 0));
		txtCodeNo.setBounds(35, 31, 164, 20);
		contentPane.add(txtCodeNo);
		txtCodeNo.setColumns(10);
		
		txtGrade = new JTextField();
		txtGrade.setText("Grade 11 - First Semester                                                                                                                            SCHOOL YEAR: 2020-2021");
		txtGrade.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtGrade.setBounds(35, 62, 1001, 20);
		contentPane.add(txtGrade);
		txtGrade.setColumns(10);
		
		txtstGrading = new JTextField();
		txtstGrading.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		txtstGrading.setText("1st\r\nGrading.");
		txtstGrading.setBackground(new Color(139, 0, 0));
		txtstGrading.setBounds(500, 31, 86, 20);
		contentPane.add(txtstGrading);
		txtstGrading.setColumns(10);
		
		txtndGrading = new JTextField();
		txtndGrading.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		txtndGrading.setText("2nd\r\nGrading");
		txtndGrading.setBackground(new Color(139, 0, 0));
		txtndGrading.setBounds(596, 31, 86, 20);
		contentPane.add(txtndGrading);
		txtndGrading.setColumns(10);
		
		txtAverage = new JTextField();
		txtAverage.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		txtAverage.setText("AVERAGE. ");
		txtAverage.setBackground(new Color(139, 0, 0));
		txtAverage.setBounds(692, 31, 86, 20);
		contentPane.add(txtAverage);
		txtAverage.setColumns(10);
		
		txtRemarks = new JTextField();
		txtRemarks.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		txtRemarks.setHorizontalAlignment(SwingConstants.CENTER);
		txtRemarks.setText("Remarks");
		txtRemarks.setBackground(new Color(139, 0, 0));
		txtRemarks.setBounds(788, 31, 86, 20);
		contentPane.add(txtRemarks);
		txtRemarks.setColumns(10);
		
		txtUnitsEarned = new JTextField();
		txtUnitsEarned.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		txtUnitsEarned.setText("units\r\nearned");
		txtUnitsEarned.setBackground(new Color(139, 0, 0));
		txtUnitsEarned.setBounds(895, 32, 92, 20);
		contentPane.add(txtUnitsEarned);
		txtUnitsEarned.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setHorizontalAlignment(SwingConstants.CENTER);
		textField_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_7.setText("93");
		textField_7.setBounds(500, 92, 86, 20);
		contentPane.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_8.setText("91");
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setBounds(596, 93, 86, 20);
		contentPane.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setText("92");
		textField_9.setBounds(692, 93, 86, 20);
		contentPane.add(textField_9);
		textField_9.setColumns(10);
		
		txtPassed = new JTextField();
		txtPassed.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		txtPassed.setHorizontalAlignment(SwingConstants.CENTER);
		txtPassed.setText("PASSED");
		txtPassed.setBounds(788, 93, 86, 20);
		contentPane.add(txtPassed);
		txtPassed.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setHorizontalAlignment(SwingConstants.CENTER);
		textField_11.setText("4.0");
		textField_11.setBounds(901, 93, 86, 20);
		contentPane.add(textField_11);
		textField_11.setColumns(10);
		
		textField_12 = new JTextField();
		textField_12.setHorizontalAlignment(SwingConstants.CENTER);
		textField_12.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_12.setText("90");
		textField_12.setBounds(500, 124, 86, 20);
		contentPane.add(textField_12);
		textField_12.setColumns(10);
		
		textField_13 = new JTextField();
		textField_13.setHorizontalAlignment(SwingConstants.CENTER);
		textField_13.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_13.setText("94");
		textField_13.setBounds(500, 159, 86, 20);
		contentPane.add(textField_13);
		textField_13.setColumns(10);
		
		textField_14 = new JTextField();
		textField_14.setHorizontalAlignment(SwingConstants.CENTER);
		textField_14.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_14.setText("96");
		textField_14.setBounds(500, 190, 86, 20);
		contentPane.add(textField_14);
		textField_14.setColumns(10);
		
		textField_15 = new JTextField();
		textField_15.setHorizontalAlignment(SwingConstants.CENTER);
		textField_15.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_15.setText("92");
		textField_15.setBounds(500, 221, 86, 20);
		contentPane.add(textField_15);
		textField_15.setColumns(10);
		
		textField_16 = new JTextField();
		textField_16.setHorizontalAlignment(SwingConstants.CENTER);
		textField_16.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_16.setText("96");
		textField_16.setBounds(500, 246, 86, 20);
		contentPane.add(textField_16);
		textField_16.setColumns(10);
		
		textField_17 = new JTextField();
		textField_17.setHorizontalAlignment(SwingConstants.CENTER);
		textField_17.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_17.setText("91\r\n");
		textField_17.setBounds(500, 277, 86, 20);
		contentPane.add(textField_17);
		textField_17.setColumns(10);
		
		textField_18 = new JTextField();
		textField_18.setHorizontalAlignment(SwingConstants.CENTER);
		textField_18.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_18.setText("98");
		textField_18.setBounds(500, 308, 86, 20);
		contentPane.add(textField_18);
		textField_18.setColumns(10);
		
		textField_19 = new JTextField();
		textField_19.setHorizontalAlignment(SwingConstants.CENTER);
		textField_19.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_19.setText("92");
		textField_19.setBounds(596, 124, 86, 20);
		contentPane.add(textField_19);
		textField_19.setColumns(10);
		
		textField_20 = new JTextField();
		textField_20.setHorizontalAlignment(SwingConstants.CENTER);
		textField_20.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_20.setText("94");
		textField_20.setBounds(596, 159, 86, 20);
		contentPane.add(textField_20);
		textField_20.setColumns(10);
		
		textField_21 = new JTextField();
		textField_21.setHorizontalAlignment(SwingConstants.CENTER);
		textField_21.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_21.setText("94");
		textField_21.setBounds(596, 190, 86, 20);
		contentPane.add(textField_21);
		textField_21.setColumns(10);
		
		textField_22 = new JTextField();
		textField_22.setHorizontalAlignment(SwingConstants.CENTER);
		textField_22.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_22.setText("93");
		textField_22.setBounds(596, 221, 86, 20);
		contentPane.add(textField_22);
		textField_22.setColumns(10);
		
		textField_23 = new JTextField();
		textField_23.setHorizontalAlignment(SwingConstants.CENTER);
		textField_23.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_23.setText("97\r\n");
		textField_23.setBounds(596, 246, 86, 20);
		contentPane.add(textField_23);
		textField_23.setColumns(10);
		
		textField_24 = new JTextField();
		textField_24.setHorizontalAlignment(SwingConstants.CENTER);
		textField_24.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_24.setText("93");
		textField_24.setBounds(596, 277, 86, 20);
		contentPane.add(textField_24);
		textField_24.setColumns(10);
		
		textField_25 = new JTextField();
		textField_25.setHorizontalAlignment(SwingConstants.CENTER);
		textField_25.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_25.setText("97");
		textField_25.setBounds(596, 308, 86, 20);
		contentPane.add(textField_25);
		textField_25.setColumns(10);
		
		textField_26 = new JTextField();
		textField_26.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_26.setHorizontalAlignment(SwingConstants.CENTER);
		textField_26.setText("91");
		textField_26.setBounds(692, 124, 86, 20);
		contentPane.add(textField_26);
		textField_26.setColumns(10);
		
		textField_27 = new JTextField();
		textField_27.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_27.setHorizontalAlignment(SwingConstants.CENTER);
		textField_27.setText("94");
		textField_27.setBounds(692, 159, 86, 20);
		contentPane.add(textField_27);
		textField_27.setColumns(10);
		
		textField_28 = new JTextField();
		textField_28.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_28.setHorizontalAlignment(SwingConstants.CENTER);
		textField_28.setText("95");
		textField_28.setBounds(692, 190, 86, 20);
		contentPane.add(textField_28);
		textField_28.setColumns(10);
		
		textField_29 = new JTextField();
		textField_29.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_29.setHorizontalAlignment(SwingConstants.CENTER);
		textField_29.setText("92.5");
		textField_29.setBounds(692, 221, 86, 20);
		contentPane.add(textField_29);
		textField_29.setColumns(10);
		
		textField_30 = new JTextField();
		textField_30.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_30.setHorizontalAlignment(SwingConstants.CENTER);
		textField_30.setText("96.5\r");
		textField_30.setBounds(692, 246, 86, 20);
		contentPane.add(textField_30);
		textField_30.setColumns(10);
		
		textField_31 = new JTextField();
		textField_31.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_31.setHorizontalAlignment(SwingConstants.CENTER);
		textField_31.setText("92\r\r\n");
		textField_31.setBounds(692, 277, 86, 20);
		contentPane.add(textField_31);
		textField_31.setColumns(10);
		
		textField_32 = new JTextField();
		textField_32.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_32.setHorizontalAlignment(SwingConstants.CENTER);
		textField_32.setText("97.5\r\n");
		textField_32.setBounds(692, 308, 86, 20);
		contentPane.add(textField_32);
		textField_32.setColumns(10);
		
		txtPassed_1 = new JTextField();
		txtPassed_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		txtPassed_1.setHorizontalAlignment(SwingConstants.CENTER);
		txtPassed_1.setText("PASSED");
		txtPassed_1.setBounds(788, 124, 86, 20);
		contentPane.add(txtPassed_1);
		txtPassed_1.setColumns(10);
		
		textField_40 = new JTextField();
		textField_40.setHorizontalAlignment(SwingConstants.CENTER);
		textField_40.setText("4.0");
		textField_40.setBounds(901, 124, 86, 20);
		contentPane.add(textField_40);
		textField_40.setColumns(10);
		
		textField_41 = new JTextField();
		textField_41.setHorizontalAlignment(SwingConstants.CENTER);
		textField_41.setText("4.0");
		textField_41.setBounds(901, 160, 86, 20);
		contentPane.add(textField_41);
		textField_41.setColumns(10);
		
		textField_42 = new JTextField();
		textField_42.setText("4.0");
		textField_42.setHorizontalAlignment(SwingConstants.CENTER);
		textField_42.setBounds(901, 190, 86, 20);
		contentPane.add(textField_42);
		textField_42.setColumns(10);
		
		textField_43 = new JTextField();
		textField_43.setHorizontalAlignment(SwingConstants.CENTER);
		textField_43.setText("4.0");
		textField_43.setBounds(901, 221, 86, 20);
		contentPane.add(textField_43);
		textField_43.setColumns(10);
		
		textField_44 = new JTextField();
		textField_44.setHorizontalAlignment(SwingConstants.CENTER);
		textField_44.setText("4.0");
		textField_44.setBounds(901, 246, 86, 20);
		contentPane.add(textField_44);
		textField_44.setColumns(10);
		
		textField_45 = new JTextField();
		textField_45.setHorizontalAlignment(SwingConstants.CENTER);
		textField_45.setText("4.0");
		textField_45.setBounds(901, 277, 86, 20);
		contentPane.add(textField_45);
		textField_45.setColumns(10);
		
		textField_46 = new JTextField();
		textField_46.setHorizontalAlignment(SwingConstants.CENTER);
		textField_46.setText("4.0");
		textField_46.setBounds(901, 308, 86, 20);
		contentPane.add(textField_46);
		textField_46.setColumns(10);
		
		txtCorOral = new JTextField();
		txtCorOral.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCorOral.setText("COR 001( Oral Communication in Context\r");
		txtCorOral.setBounds(35, 93, 458, 20);
		contentPane.add(txtCorOral);
		txtCorOral.setColumns(10);
		
		txtCorkomunikasyon = new JTextField();
		txtCorkomunikasyon.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCorkomunikasyon.setText("COR 003 (Komunikasyon at Pananaliksik\r");
		txtCorkomunikasyon.setColumns(10);
		txtCorkomunikasyon.setBounds(35, 124, 458, 20);
		contentPane.add(txtCorkomunikasyon);
		
		txtCor = new JTextField();
		txtCor.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCor.setText("COR 005 ( Genreal Mathematics)\r");
		txtCor.setColumns(10);
		txtCor.setBounds(35, 155, 455, 20);
		contentPane.add(txtCor);
		
		txtCor_1 = new JTextField();
		txtCor_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCor_1.setText("COR 008 ( Earth Science)\r");
		txtCor_1.setColumns(10);
		txtCor_1.setBounds(35, 190, 455, 20);
		contentPane.add(txtCor_1);
		
		txtCorst = new JTextField();
		txtCorst.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCorst.setText("COR 011 (21st Century Literature\r");
		txtCorst.setColumns(10);
		txtCorst.setBounds(35, 221, 455, 20);
		contentPane.add(txtCorst);
		
		txtCorIntroduction = new JTextField();
		txtCorIntroduction.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCorIntroduction.setText("COR 015( Introduction to the Philosophy\r");
		txtCorIntroduction.setColumns(10);
		txtCorIntroduction.setBounds(35, 246, 458, 20);
		contentPane.add(txtCorIntroduction);
		
		txtCorphysical = new JTextField();
		txtCorphysical.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtCorphysical.setText("COR 017 (Physical Education and Health\r");
		txtCorphysical.setColumns(10);
		txtCorphysical.setBounds(35, 277, 455, 20);
		contentPane.add(txtCorphysical);
		
		txtAap = new JTextField();
		txtAap.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtAap.setText("AAP 002 ( English for academic and prof");
		txtAap.setColumns(10);
		txtAap.setBounds(35, 308, 458, 20);
		contentPane.add(txtAap);
		
		txtSubjectDesciption = new JTextField();
		txtSubjectDesciption.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtSubjectDesciption.setText(" Subject Desciption\r");
		txtSubjectDesciption.setHorizontalAlignment(SwingConstants.CENTER);
		txtSubjectDesciption.setBackground(new Color(139, 0, 0));
		txtSubjectDesciption.setColumns(10);
		txtSubjectDesciption.setBounds(209, 31, 281, 20);
		contentPane.add(txtSubjectDesciption);
		
		txtOutlineOfSenior = new JTextField();
		txtOutlineOfSenior.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		txtOutlineOfSenior.setHorizontalAlignment(SwingConstants.CENTER);
		txtOutlineOfSenior.setText("OUTLINE OF SENIOR HIGH SCHOOL SUBJECTS\r");
		txtOutlineOfSenior.setBounds(180, 0, 598, 20);
		contentPane.add(txtOutlineOfSenior);
		txtOutlineOfSenior.setColumns(10);
		
		txtSsp = new JTextField();
		txtSsp.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtSsp.setText("SSP 001 ( Student Success Program 1)");
		txtSsp.setBounds(31, 339, 462, 20);
		contentPane.add(txtSsp);
		txtSsp.setColumns(10);
		
		txtCompleted = new JTextField();
		txtCompleted.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtCompleted.setHorizontalAlignment(SwingConstants.CENTER);
		txtCompleted.setText("COMPLETED");
		txtCompleted.setBounds(500, 339, 374, 20);
		contentPane.add(txtCompleted);
		txtCompleted.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setHorizontalAlignment(SwingConstants.CENTER);
		textField_2.setText("3.0");
		textField_2.setBounds(901, 339, 86, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		txtTotalUnitsEarned = new JTextField();
		txtTotalUnitsEarned.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtTotalUnitsEarned.setText("Total Units Earned 32.0\r");
		txtTotalUnitsEarned.setHorizontalAlignment(SwingConstants.RIGHT);
		txtTotalUnitsEarned.setBounds(35, 370, 952, 20);
		contentPane.add(txtTotalUnitsEarned);
		txtTotalUnitsEarned.setColumns(10);
		
		textField = new JTextField();
		textField.setText("PASSED");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField.setColumns(10);
		textField.setBounds(788, 160, 86, 20);
		contentPane.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setText("PASSED");
		textField_1.setHorizontalAlignment(SwingConstants.CENTER);
		textField_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_1.setColumns(10);
		textField_1.setBounds(788, 191, 86, 20);
		contentPane.add(textField_1);
		
		textField_3 = new JTextField();
		textField_3.setText("PASSED");
		textField_3.setHorizontalAlignment(SwingConstants.CENTER);
		textField_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_3.setColumns(10);
		textField_3.setBounds(788, 222, 86, 20);
		contentPane.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setText("PASSED");
		textField_4.setHorizontalAlignment(SwingConstants.CENTER);
		textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_4.setColumns(10);
		textField_4.setBounds(788, 247, 86, 20);
		contentPane.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setText("PASSED");
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_5.setColumns(10);
		textField_5.setBounds(788, 278, 86, 20);
		contentPane.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setText("PASSED");
		textField_6.setHorizontalAlignment(SwingConstants.CENTER);
		textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_6.setColumns(10);
		textField_6.setBounds(788, 309, 86, 20);
		contentPane.add(textField_6);
	}

}
