import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.ImageIcon;

public class scrap extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					scrap frame = new scrap();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public scrap() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1252, 783);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBounds(30, 11, 1096, 707);
		contentPane.add(contentPane_1);
		
		textField = new JTextField();
		textField.setText("NAME OF TVL  STUDENTS\r\n");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setForeground(Color.PINK);
		textField.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		textField.setColumns(10);
		textField.setBounds(106, 184, 906, 64);
		contentPane_1.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setText("1.ALLEJE,REGUEL JAMESON\r\n");
		textField_1.setHorizontalAlignment(SwingConstants.LEFT);
		textField_1.setForeground(Color.BLACK);
		textField_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_1.setColumns(10);
		textField_1.setBounds(99, 284, 506, 30);
		contentPane_1.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setText("2.Altamirano, Liliene Ylena");
		textField_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_2.setColumns(10);
		textField_2.setBounds(99, 325, 506, 30);
		contentPane_1.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setText("3. Fortunado, Thraia Gabriella ");
		textField_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_3.setColumns(10);
		textField_3.setBounds(99, 366, 506, 30);
		contentPane_1.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setText("4. Galvez, Nieves Solanna ");
		textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_4.setColumns(10);
		textField_4.setBounds(99, 407, 506, 30);
		contentPane_1.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setText("5. Hidalgo, Vicentius Theron");
		textField_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_5.setColumns(10);
		textField_5.setBounds(99, 448, 506, 30);
		contentPane_1.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setText("6. Leviste, Zariyah Isla");
		textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_6.setColumns(10);
		textField_6.setBounds(99, 489, 506, 30);
		contentPane_1.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setText("7. Mercadejas, Antonius Lienzo");
		textField_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_7.setColumns(10);
		textField_7.setBounds(99, 530, 506, 30);
		contentPane_1.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setText("8. Riego, Radleigh Vesarius\r\n");
		textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_8.setColumns(10);
		textField_8.setBounds(99, 571, 507, 30);
		contentPane_1.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setText("9. Riego, Percival Archer");
		textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_9.setColumns(10);
		textField_9.setBounds(99, 615, 506, 30);
		contentPane_1.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setText("10. Samuel, Eurydyce Amethyst");
		textField_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_10.setColumns(10);
		textField_10.setBounds(99, 656, 506, 30);
		contentPane_1.add(textField_10);
		
		JButton btnNewButton = new JButton("Info & Grades");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton.setBounds(644, 289, 259, 23);
		contentPane_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Info & Grades");
		btnNewButton_1.setForeground(Color.RED);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_1.setBounds(644, 332, 259, 23);
		contentPane_1.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Info & Grades");
		btnNewButton_2.setForeground(Color.RED);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_2.setBounds(644, 371, 259, 23);
		contentPane_1.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Info & Grades");
		btnNewButton_3.setForeground(Color.RED);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_3.setBounds(644, 412, 259, 23);
		contentPane_1.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Info & Grades");
		btnNewButton_4.setForeground(Color.RED);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_4.setBounds(644, 453, 259, 23);
		contentPane_1.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Info & Grades");
		btnNewButton_5.setForeground(Color.RED);
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_5.setBounds(644, 494, 259, 23);
		contentPane_1.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Info & Grades");
		btnNewButton_6.setForeground(Color.RED);
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_6.setBounds(644, 535, 259, 23);
		contentPane_1.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("Info & Grades");
		btnNewButton_7.setForeground(Color.RED);
		btnNewButton_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_7.setBounds(644, 576, 259, 23);
		contentPane_1.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("Info & Grades");
		btnNewButton_8.setForeground(Color.RED);
		btnNewButton_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_8.setBounds(644, 620, 259, 23);
		contentPane_1.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("Info & Grades");
		btnNewButton_9.setForeground(Color.RED);
		btnNewButton_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 14));
		btnNewButton_9.setBounds(644, 661, 259, 23);
		contentPane_1.add(btnNewButton_9);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\MIKO\\Downloads\\276986862_4772617479513843_9024251935593852877_n.jpg"));
		lblNewLabel.setBounds(274, 11, 554, 162);
		contentPane_1.add(lblNewLabel);
	}

}
