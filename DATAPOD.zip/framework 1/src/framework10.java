import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;

public class framework10 extends JFrame {

	private JPanel contentPane;
	private JTextField txtNamezariyahIslaLeviste;
	private JTextField txtLrn;
	private JTextField txtDateOfBirth;
	private JTextField txtParentguardianMrAnd;
	private JTextField textField_4;
	private JTextField txtElementaryUniversityOf;
	private JTextField textField_6;
	private JTextField txtSexFemale;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework10 frame = new framework10();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework10() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1089, 792);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.add(contentPane_1, BorderLayout.CENTER);
		contentPane_1.setLayout(null);
		
		txtNamezariyahIslaLeviste = new JTextField();
		txtNamezariyahIslaLeviste.setBounds(34, 61, 352, 31);
		txtNamezariyahIslaLeviste.setText("Name:Zariyah Isla Leviste");
		txtNamezariyahIslaLeviste.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtNamezariyahIslaLeviste.setColumns(10);
		contentPane_1.add(txtNamezariyahIslaLeviste);
		
		txtLrn = new JTextField();
		txtLrn.setBounds(34, 103, 352, 31);
		txtLrn.setText("LRN: 270867428769\r\n");
		txtLrn.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtLrn.setColumns(10);
		contentPane_1.add(txtLrn);
		
		txtDateOfBirth = new JTextField();
		txtDateOfBirth.setBounds(34, 145, 352, 31);
		txtDateOfBirth.setText("Date of Birth: 2/5/04\r\n");
		txtDateOfBirth.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtDateOfBirth.setColumns(10);
		contentPane_1.add(txtDateOfBirth);
		
		txtParentguardianMrAnd = new JTextField();
		txtParentguardianMrAnd.setBounds(34, 187, 352, 31);
		txtParentguardianMrAnd.setText("Parent/Guardian: Mr. and Mrs. Leviste");
		txtParentguardianMrAnd.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtParentguardianMrAnd.setColumns(10);
		contentPane_1.add(txtParentguardianMrAnd);
		
		textField_4 = new JTextField();
		textField_4.setBounds(34, 236, 352, 31);
		textField_4.setText("School Attended:");
		textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_4.setColumns(10);
		contentPane_1.add(textField_4);
		
		txtElementaryUniversityOf = new JTextField();
		txtElementaryUniversityOf.setBounds(34, 278, 352, 31);
		txtElementaryUniversityOf.setText("Elementary: University of Cebu\r\n");
		txtElementaryUniversityOf.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtElementaryUniversityOf.setColumns(10);
		contentPane_1.add(txtElementaryUniversityOf);
		
		textField_6 = new JTextField();
		textField_6.setBounds(33, 320, 352, 30);
		textField_6.setText("Junior highschool: Southwestern University\r\n");
		textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_6.setColumns(10);
		contentPane_1.add(textField_6);
		
		txtSexFemale = new JTextField();
		txtSexFemale.setBounds(448, 66, 242, 24);
		txtSexFemale.setText("Sex: Female\r\n");
		txtSexFemale.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtSexFemale.setColumns(10);
		contentPane_1.add(txtSexFemale);
		
		textField_8 = new JTextField();
		textField_8.setBounds(448, 325, 242, 20);
		textField_8.setText("Year Graduated: 2021");
		textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_8.setColumns(10);
		contentPane_1.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setBounds(448, 283, 242, 20);
		textField_9.setText("Year Graduated:: 2017");
		textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_9.setColumns(10);
		contentPane_1.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setBounds(34, 484, 352, 31);
		textField_10.setText("TRACK:                         ACADEMIC");
		textField_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_10.setColumns(10);
		contentPane_1.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setBounds(34, 548, 352, 31);
		textField_11.setText("STRAND:                               TVL");
		textField_11.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_11.setColumns(10);
		contentPane_1.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setBounds(448, 486, 333, 26);
		textField_12.setText("BATCH: 2021-2022");
		textField_12.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_12.setColumns(10);
		contentPane_1.add(textField_12);
	}

}
