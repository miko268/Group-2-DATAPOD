import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;

public class framework14grade extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_28;
	private JTextField textField_29;
	private JTextField textField_30;
	private JTextField textField_31;
	private JTextField textField_32;
	private JTextField textField_33;
	private JTextField textField_34;
	private JTextField textField_35;
	private JTextField textField_36;
	private JTextField textField_37;
	private JTextField textField_38;
	private JTextField textField_39;
	private JTextField textField_40;
	private JTextField textField_41;
	private JTextField textField_42;
	private JTextField textField_43;
	private JTextField textField_44;
	private JTextField textField_45;
	private JTextField textField_46;
	private JTextField textField_47;
	private JTextField textField_48;
	private JTextField textField_49;
	private JTextField textField_50;
	private JTextField textField_51;
	private JTextField textField_52;
	private JTextField textField_53;
	private JTextField textField_54;
	private JTextField textField_55;
	private JTextField textField_56;
	private JTextField textField_57;
	private JTextField textField_58;
	private JTextField textField_59;
	private JTextField textField_60;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework14grade frame = new framework14grade();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework14grade() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1089, 910);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel contentPane_1 = new JPanel();
		contentPane_1.setLayout(null);
		contentPane_1.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane_1.setBounds(10, 11, 1076, 796);
		contentPane.add(contentPane_1);
		
		textField = new JTextField();
		textField.setText("Code no. ");
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField.setColumns(10);
		textField.setBackground(new Color(139, 0, 0));
		textField.setBounds(35, 31, 164, 20);
		contentPane_1.add(textField);
		
		textField_1 = new JTextField();
		textField_1.setText("Grade 11 - First Semester                                                                                                                            SCHOOL YEAR: 2020-2021");
		textField_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_1.setColumns(10);
		textField_1.setBounds(35, 62, 1001, 20);
		contentPane_1.add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setText("1st\r\nGrading.");
		textField_2.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_2.setColumns(10);
		textField_2.setBackground(new Color(139, 0, 0));
		textField_2.setBounds(500, 31, 86, 20);
		contentPane_1.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setText("2nd\r\nGrading");
		textField_3.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_3.setColumns(10);
		textField_3.setBackground(new Color(139, 0, 0));
		textField_3.setBounds(596, 31, 86, 20);
		contentPane_1.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setText("AVERAGE. ");
		textField_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_4.setColumns(10);
		textField_4.setBackground(new Color(139, 0, 0));
		textField_4.setBounds(692, 31, 86, 20);
		contentPane_1.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setText("Remarks");
		textField_5.setHorizontalAlignment(SwingConstants.CENTER);
		textField_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_5.setColumns(10);
		textField_5.setBackground(new Color(139, 0, 0));
		textField_5.setBounds(788, 31, 86, 20);
		contentPane_1.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setText("units\r\nearned");
		textField_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_6.setColumns(10);
		textField_6.setBackground(new Color(139, 0, 0));
		textField_6.setBounds(895, 32, 92, 20);
		contentPane_1.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setText("93");
		textField_7.setHorizontalAlignment(SwingConstants.CENTER);
		textField_7.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_7.setColumns(10);
		textField_7.setBounds(500, 92, 86, 20);
		contentPane_1.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setText("91");
		textField_8.setHorizontalAlignment(SwingConstants.CENTER);
		textField_8.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_8.setColumns(10);
		textField_8.setBounds(596, 93, 86, 20);
		contentPane_1.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setText("92");
		textField_9.setHorizontalAlignment(SwingConstants.CENTER);
		textField_9.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_9.setColumns(10);
		textField_9.setBounds(692, 93, 86, 20);
		contentPane_1.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setText("PASSED");
		textField_10.setHorizontalAlignment(SwingConstants.CENTER);
		textField_10.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_10.setColumns(10);
		textField_10.setBounds(788, 93, 86, 20);
		contentPane_1.add(textField_10);
		
		textField_11 = new JTextField();
		textField_11.setText("4.0");
		textField_11.setHorizontalAlignment(SwingConstants.CENTER);
		textField_11.setColumns(10);
		textField_11.setBounds(901, 93, 86, 20);
		contentPane_1.add(textField_11);
		
		textField_12 = new JTextField();
		textField_12.setText("90");
		textField_12.setHorizontalAlignment(SwingConstants.CENTER);
		textField_12.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_12.setColumns(10);
		textField_12.setBounds(500, 124, 86, 20);
		contentPane_1.add(textField_12);
		
		textField_13 = new JTextField();
		textField_13.setText("94");
		textField_13.setHorizontalAlignment(SwingConstants.CENTER);
		textField_13.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_13.setColumns(10);
		textField_13.setBounds(500, 159, 86, 20);
		contentPane_1.add(textField_13);
		
		textField_14 = new JTextField();
		textField_14.setText("96");
		textField_14.setHorizontalAlignment(SwingConstants.CENTER);
		textField_14.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_14.setColumns(10);
		textField_14.setBounds(500, 190, 86, 20);
		contentPane_1.add(textField_14);
		
		textField_15 = new JTextField();
		textField_15.setText("92");
		textField_15.setHorizontalAlignment(SwingConstants.CENTER);
		textField_15.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_15.setColumns(10);
		textField_15.setBounds(500, 221, 86, 20);
		contentPane_1.add(textField_15);
		
		textField_16 = new JTextField();
		textField_16.setText("96");
		textField_16.setHorizontalAlignment(SwingConstants.CENTER);
		textField_16.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_16.setColumns(10);
		textField_16.setBounds(500, 246, 86, 20);
		contentPane_1.add(textField_16);
		
		textField_17 = new JTextField();
		textField_17.setText("91\r\n");
		textField_17.setHorizontalAlignment(SwingConstants.CENTER);
		textField_17.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_17.setColumns(10);
		textField_17.setBounds(500, 277, 86, 20);
		contentPane_1.add(textField_17);
		
		textField_18 = new JTextField();
		textField_18.setText("98");
		textField_18.setHorizontalAlignment(SwingConstants.CENTER);
		textField_18.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_18.setColumns(10);
		textField_18.setBounds(500, 308, 86, 20);
		contentPane_1.add(textField_18);
		
		textField_19 = new JTextField();
		textField_19.setText("92");
		textField_19.setHorizontalAlignment(SwingConstants.CENTER);
		textField_19.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_19.setColumns(10);
		textField_19.setBounds(596, 124, 86, 20);
		contentPane_1.add(textField_19);
		
		textField_20 = new JTextField();
		textField_20.setText("94");
		textField_20.setHorizontalAlignment(SwingConstants.CENTER);
		textField_20.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_20.setColumns(10);
		textField_20.setBounds(596, 159, 86, 20);
		contentPane_1.add(textField_20);
		
		textField_21 = new JTextField();
		textField_21.setText("94");
		textField_21.setHorizontalAlignment(SwingConstants.CENTER);
		textField_21.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_21.setColumns(10);
		textField_21.setBounds(596, 190, 86, 20);
		contentPane_1.add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.setText("93");
		textField_22.setHorizontalAlignment(SwingConstants.CENTER);
		textField_22.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_22.setColumns(10);
		textField_22.setBounds(596, 221, 86, 20);
		contentPane_1.add(textField_22);
		
		textField_23 = new JTextField();
		textField_23.setText("97\r\n");
		textField_23.setHorizontalAlignment(SwingConstants.CENTER);
		textField_23.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_23.setColumns(10);
		textField_23.setBounds(596, 246, 86, 20);
		contentPane_1.add(textField_23);
		
		textField_24 = new JTextField();
		textField_24.setText("93");
		textField_24.setHorizontalAlignment(SwingConstants.CENTER);
		textField_24.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_24.setColumns(10);
		textField_24.setBounds(596, 277, 86, 20);
		contentPane_1.add(textField_24);
		
		textField_25 = new JTextField();
		textField_25.setText("97");
		textField_25.setHorizontalAlignment(SwingConstants.CENTER);
		textField_25.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_25.setColumns(10);
		textField_25.setBounds(596, 308, 86, 20);
		contentPane_1.add(textField_25);
		
		textField_26 = new JTextField();
		textField_26.setText("91");
		textField_26.setHorizontalAlignment(SwingConstants.CENTER);
		textField_26.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_26.setColumns(10);
		textField_26.setBounds(692, 124, 86, 20);
		contentPane_1.add(textField_26);
		
		textField_27 = new JTextField();
		textField_27.setText("94");
		textField_27.setHorizontalAlignment(SwingConstants.CENTER);
		textField_27.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_27.setColumns(10);
		textField_27.setBounds(692, 159, 86, 20);
		contentPane_1.add(textField_27);
		
		textField_28 = new JTextField();
		textField_28.setText("95");
		textField_28.setHorizontalAlignment(SwingConstants.CENTER);
		textField_28.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_28.setColumns(10);
		textField_28.setBounds(692, 190, 86, 20);
		contentPane_1.add(textField_28);
		
		textField_29 = new JTextField();
		textField_29.setText("92.5");
		textField_29.setHorizontalAlignment(SwingConstants.CENTER);
		textField_29.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_29.setColumns(10);
		textField_29.setBounds(692, 221, 86, 20);
		contentPane_1.add(textField_29);
		
		textField_30 = new JTextField();
		textField_30.setText("96.5\r");
		textField_30.setHorizontalAlignment(SwingConstants.CENTER);
		textField_30.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_30.setColumns(10);
		textField_30.setBounds(692, 246, 86, 20);
		contentPane_1.add(textField_30);
		
		textField_31 = new JTextField();
		textField_31.setText("92\r\r\n");
		textField_31.setHorizontalAlignment(SwingConstants.CENTER);
		textField_31.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_31.setColumns(10);
		textField_31.setBounds(692, 277, 86, 20);
		contentPane_1.add(textField_31);
		
		textField_32 = new JTextField();
		textField_32.setText("97.5\r\n");
		textField_32.setHorizontalAlignment(SwingConstants.CENTER);
		textField_32.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_32.setColumns(10);
		textField_32.setBounds(692, 308, 86, 20);
		contentPane_1.add(textField_32);
		
		textField_33 = new JTextField();
		textField_33.setText("PASSED");
		textField_33.setHorizontalAlignment(SwingConstants.CENTER);
		textField_33.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_33.setColumns(10);
		textField_33.setBounds(788, 124, 86, 20);
		contentPane_1.add(textField_33);
		
		textField_34 = new JTextField();
		textField_34.setText("4.0");
		textField_34.setHorizontalAlignment(SwingConstants.CENTER);
		textField_34.setColumns(10);
		textField_34.setBounds(901, 124, 86, 20);
		contentPane_1.add(textField_34);
		
		textField_35 = new JTextField();
		textField_35.setText("4.0");
		textField_35.setHorizontalAlignment(SwingConstants.CENTER);
		textField_35.setColumns(10);
		textField_35.setBounds(901, 160, 86, 20);
		contentPane_1.add(textField_35);
		
		textField_36 = new JTextField();
		textField_36.setText("4.0");
		textField_36.setHorizontalAlignment(SwingConstants.CENTER);
		textField_36.setColumns(10);
		textField_36.setBounds(901, 190, 86, 20);
		contentPane_1.add(textField_36);
		
		textField_37 = new JTextField();
		textField_37.setText("4.0");
		textField_37.setHorizontalAlignment(SwingConstants.CENTER);
		textField_37.setColumns(10);
		textField_37.setBounds(901, 221, 86, 20);
		contentPane_1.add(textField_37);
		
		textField_38 = new JTextField();
		textField_38.setText("4.0");
		textField_38.setHorizontalAlignment(SwingConstants.CENTER);
		textField_38.setColumns(10);
		textField_38.setBounds(901, 246, 86, 20);
		contentPane_1.add(textField_38);
		
		textField_39 = new JTextField();
		textField_39.setText("4.0");
		textField_39.setHorizontalAlignment(SwingConstants.CENTER);
		textField_39.setColumns(10);
		textField_39.setBounds(901, 277, 86, 20);
		contentPane_1.add(textField_39);
		
		textField_40 = new JTextField();
		textField_40.setText("4.0");
		textField_40.setHorizontalAlignment(SwingConstants.CENTER);
		textField_40.setColumns(10);
		textField_40.setBounds(901, 308, 86, 20);
		contentPane_1.add(textField_40);
		
		textField_41 = new JTextField();
		textField_41.setText("COR 001( Oral Communication in Context\r");
		textField_41.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_41.setColumns(10);
		textField_41.setBounds(35, 93, 458, 20);
		contentPane_1.add(textField_41);
		
		textField_42 = new JTextField();
		textField_42.setText("COR 003 (Komunikasyon at Pananaliksik\r");
		textField_42.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_42.setColumns(10);
		textField_42.setBounds(35, 124, 458, 20);
		contentPane_1.add(textField_42);
		
		textField_43 = new JTextField();
		textField_43.setText("COR 005 ( Genreal Mathematics)\r");
		textField_43.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_43.setColumns(10);
		textField_43.setBounds(35, 155, 455, 20);
		contentPane_1.add(textField_43);
		
		textField_44 = new JTextField();
		textField_44.setText("COR 008 ( Earth Science)\r");
		textField_44.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_44.setColumns(10);
		textField_44.setBounds(35, 190, 455, 20);
		contentPane_1.add(textField_44);
		
		textField_45 = new JTextField();
		textField_45.setText("COR 011 (21st Century Literature\r");
		textField_45.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_45.setColumns(10);
		textField_45.setBounds(35, 221, 455, 20);
		contentPane_1.add(textField_45);
		
		textField_46 = new JTextField();
		textField_46.setText("COR 015( Introduction to the Philosophy\r");
		textField_46.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_46.setColumns(10);
		textField_46.setBounds(35, 246, 458, 20);
		contentPane_1.add(textField_46);
		
		textField_47 = new JTextField();
		textField_47.setText("COR 017 (Physical Education and Health\r");
		textField_47.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_47.setColumns(10);
		textField_47.setBounds(35, 277, 455, 20);
		contentPane_1.add(textField_47);
		
		textField_48 = new JTextField();
		textField_48.setText("AAP 002 ( English for academic and prof");
		textField_48.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_48.setColumns(10);
		textField_48.setBounds(35, 308, 458, 20);
		contentPane_1.add(textField_48);
		
		textField_49 = new JTextField();
		textField_49.setText(" Subject Desciption\r");
		textField_49.setHorizontalAlignment(SwingConstants.CENTER);
		textField_49.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_49.setColumns(10);
		textField_49.setBackground(new Color(139, 0, 0));
		textField_49.setBounds(209, 31, 281, 20);
		contentPane_1.add(textField_49);
		
		textField_50 = new JTextField();
		textField_50.setText("OUTLINE OF SENIOR HIGH SCHOOL SUBJECTS\r");
		textField_50.setHorizontalAlignment(SwingConstants.CENTER);
		textField_50.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 12));
		textField_50.setColumns(10);
		textField_50.setBounds(180, 0, 598, 20);
		contentPane_1.add(textField_50);
		
		textField_51 = new JTextField();
		textField_51.setText("SSP 001 ( Student Success Program 1)");
		textField_51.setFont(new Font("Tahoma", Font.PLAIN, 15));
		textField_51.setColumns(10);
		textField_51.setBounds(31, 339, 462, 20);
		contentPane_1.add(textField_51);
		
		textField_52 = new JTextField();
		textField_52.setText("COMPLETED");
		textField_52.setHorizontalAlignment(SwingConstants.CENTER);
		textField_52.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_52.setColumns(10);
		textField_52.setBounds(500, 339, 374, 20);
		contentPane_1.add(textField_52);
		
		textField_53 = new JTextField();
		textField_53.setText("3.0");
		textField_53.setHorizontalAlignment(SwingConstants.CENTER);
		textField_53.setColumns(10);
		textField_53.setBounds(901, 339, 86, 20);
		contentPane_1.add(textField_53);
		
		textField_54 = new JTextField();
		textField_54.setText("Total Units Earned 32.0\r");
		textField_54.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_54.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		textField_54.setColumns(10);
		textField_54.setBounds(35, 370, 952, 20);
		contentPane_1.add(textField_54);
		
		textField_55 = new JTextField();
		textField_55.setText("PASSED");
		textField_55.setHorizontalAlignment(SwingConstants.CENTER);
		textField_55.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_55.setColumns(10);
		textField_55.setBounds(788, 160, 86, 20);
		contentPane_1.add(textField_55);
		
		textField_56 = new JTextField();
		textField_56.setText("PASSED");
		textField_56.setHorizontalAlignment(SwingConstants.CENTER);
		textField_56.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_56.setColumns(10);
		textField_56.setBounds(788, 191, 86, 20);
		contentPane_1.add(textField_56);
		
		textField_57 = new JTextField();
		textField_57.setText("PASSED");
		textField_57.setHorizontalAlignment(SwingConstants.CENTER);
		textField_57.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_57.setColumns(10);
		textField_57.setBounds(788, 222, 86, 20);
		contentPane_1.add(textField_57);
		
		textField_58 = new JTextField();
		textField_58.setText("PASSED");
		textField_58.setHorizontalAlignment(SwingConstants.CENTER);
		textField_58.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_58.setColumns(10);
		textField_58.setBounds(788, 247, 86, 20);
		contentPane_1.add(textField_58);
		
		textField_59 = new JTextField();
		textField_59.setText("PASSED");
		textField_59.setHorizontalAlignment(SwingConstants.CENTER);
		textField_59.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_59.setColumns(10);
		textField_59.setBounds(788, 278, 86, 20);
		contentPane_1.add(textField_59);
		
		textField_60 = new JTextField();
		textField_60.setText("PASSED");
		textField_60.setHorizontalAlignment(SwingConstants.CENTER);
		textField_60.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		textField_60.setColumns(10);
		textField_60.setBounds(788, 309, 86, 20);
		contentPane_1.add(textField_60);
	}

}
