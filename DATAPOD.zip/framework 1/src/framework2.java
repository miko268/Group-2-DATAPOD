import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JFormattedTextField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JPasswordField;

public class framework2 extends JFrame {

	private JPanel contentPane;
	private JPasswordField passwordField;
	private JTextField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework2 frame = new framework2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1066, 789);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JFormattedTextField frmtdtxtfldEmail = new JFormattedTextField();
		frmtdtxtfldEmail.setForeground(Color.PINK);
		frmtdtxtfldEmail.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		frmtdtxtfldEmail.setText("EMAIL:");
		frmtdtxtfldEmail.setBounds(284, 274, 434, 38);
		contentPane.add(frmtdtxtfldEmail);
		
		JButton btnNewButton = new JButton("LOG IN");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.setForeground(Color.PINK);
		btnNewButton.setBounds(382, 425, 225, 44);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\MIKO\\Downloads\\SAD.png"));
		lblNewLabel.setBounds(127, 138, 807, 125);
		contentPane.add(lblNewLabel);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		passwordField.setBounds(355, 340, 363, 38);
		contentPane.add(passwordField);
		
		txtPassword = new JTextField();
		txtPassword.setForeground(Color.PINK);
		txtPassword.setHorizontalAlignment(SwingConstants.CENTER);
		txtPassword.setText("password:");
		txtPassword.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 15));
		txtPassword.setBounds(249, 340, 106, 38);
		contentPane.add(txtPassword);
		txtPassword.setColumns(10);
	}
}
