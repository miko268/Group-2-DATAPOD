import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextPane;
import javax.swing.JButton;

public class framework3 extends JFrame {

	private JPanel contentPane;
	private JTextField txtStrand;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					framework3 frame = new framework3();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public framework3() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1248, 890);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\MIKO\\Downloads\\276986862_4772617479513843_9024251935593852877_n.jpg"));
		lblNewLabel.setBounds(324, 57, 554, 163);
		contentPane.add(lblNewLabel);
		
		txtStrand = new JTextField();
		txtStrand.setForeground(Color.RED);
		txtStrand.setHorizontalAlignment(SwingConstants.CENTER);
		txtStrand.setText("STRAND:");
		txtStrand.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtStrand.setBounds(194, 269, 131, 52);
		contentPane.add(txtStrand);
		txtStrand.setColumns(10);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(335, 269, 543, 52);
		contentPane.add(textPane);
		
		JButton btnNewButton = new JButton("SEARCH");
		btnNewButton.setForeground(Color.RED);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setToolTipText("SEARCH");
		btnNewButton.setBounds(890, 269, 123, 52);
		contentPane.add(btnNewButton);
	}
}
